package com.example.college.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.college.model.Student;
import com.example.college.model.StudentDetails;
import com.example.college.service.StudentDetailsService;

@RestController
public class StudentDetailsController {
    @Autowired
    private StudentDetailsService studentDetailsService;

    @PostMapping("/postdetails")
    public StudentDetails postMethodName(@RequestBody StudentDetails studentDetails) 
    {
        return studentDetailsService.postDetails(studentDetails);
    }

    @GetMapping("/details/{id}")
    public StudentDetails getMethodName(@PathVariable("id") int id) {
        return studentDetailsService.getDetails(id);
    }
}
