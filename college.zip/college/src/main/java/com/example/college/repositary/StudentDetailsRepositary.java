package com.example.college.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.college.model.StudentDetails;

public interface StudentDetailsRepositary extends 
                JpaRepository<StudentDetails, Integer> 
{
    
}
