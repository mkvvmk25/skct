package com.example.college.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.college.model.Student;
import com.example.college.repositary.StudentRepositary;

@Service
public class StudentService {

    @Autowired
    private StudentRepositary studentRepositary;

    public Student postStudent( Student student )
    {
        return studentRepositary.save(student);
    }

    public Student getStudent( int id )
    {
        return studentRepositary.findById(id).orElse(null);
    }
}
