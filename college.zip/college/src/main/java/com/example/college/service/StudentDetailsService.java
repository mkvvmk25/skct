package com.example.college.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.college.model.StudentDetails;
import com.example.college.repositary.StudentDetailsRepositary;

@Service
public class StudentDetailsService {
    @Autowired
    private StudentDetailsRepositary studentDetailsRepositary;

     public StudentDetails postDetails( StudentDetails studentDetails )
    {
        return studentDetailsRepositary.save(studentDetails);
    }

    public StudentDetails getDetails( int id )
    {
        return studentDetailsRepositary.findById(id).orElse(null);
    }
}
